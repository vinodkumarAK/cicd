package org.baeldung.web.dto.command;

public interface ICommandDto {

}
