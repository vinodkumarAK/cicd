package org.baeldung.reddit.util;

public interface Dto {
    //
}
